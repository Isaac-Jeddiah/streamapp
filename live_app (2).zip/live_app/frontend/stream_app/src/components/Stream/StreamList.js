// client/src/components/Stream/StreamList.js

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './Stream.css'; // Import CSS for styling

const StreamList = () => {
  const [streams, setStreams] = useState([]);

  useEffect(() => {
    const fetchStreams = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/streams');
        setStreams(res.data.streams);
      } catch (err) {
        console.error(err);
      }
    };
    fetchStreams();
  }, []);

  return (
    <div className="stream-list-container">
      <h2>Live Streams</h2>
      {streams.length === 0 ? (
        <p>No live streams available.</p>
      ) : (
        <ul className="stream-list">
          {streams.map((stream) => (
            <li key={stream.id} className="stream-item">
              <Link to={`/stream/${stream.id}`} className="stream-link">
                {stream.title} by {stream.streamerUsername}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default StreamList;
